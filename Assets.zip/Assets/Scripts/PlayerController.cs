using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerController : MonoBehaviour
{
    // Define the states using an enum
    public enum State
    {
        Idle,
        Moving,
        Jumping,
        Attacking
    }

    // Create a variable to track the current state
    public State currentState;

    void Start()
    {
        // Set the initial state to Idle
        currentState = State.Idle;
    }

    void Update()
    {
        // Handle state transitions using a switch statement
        switch (currentState)
        {
            case State.Idle:
                HandleIdleState();
                break;

            case State.Moving:
                HandleMovingState();
                break;

            case State.Jumping:
                HandleJumpingState();
                break;

            case State.Attacking:
                HandleAttackingState();
                break;
        }
    }

    void HandleIdleState()
    {
        Debug.Log("Character is idle.");

        // Example transition: move to Moving state if input detected
        if (Input.GetKeyDown(KeyCode.W))
        {
            currentState = State.Moving;
        }
    }

    void HandleMovingState()
    {
        Debug.Log("Character is moving.");

        // Example transition: Jump if spacebar is pressed
        if (Input.GetKeyDown(KeyCode.Space))
        {
            currentState = State.Jumping;
        }

        // Example transition: go back to Idle if no input
        if (Input.GetKeyUp(KeyCode.W))
        {
            currentState = State.Idle;
        }
    }

    void HandleJumpingState()
    {
        Debug.Log("Character is jumping.");

        // Transition back to Idle after jump
        if (Input.GetKeyDown(KeyCode.Space))
        {
            currentState = State.Idle;
        }
    }

    void HandleAttackingState()
    {
        Debug.Log("Character is attacking.");

        // Transition back to Idle after attacking
        if (Input.GetMouseButtonDown(0))  // Left mouse button for attack
        {
            currentState = State.Idle;
        }
    }
}
